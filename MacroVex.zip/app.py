import streamlit as st
import pandas as pd
from macrovex.engine import MacroVex, Journal
from macrovex.paper import PaperBroker
from macrovex.bitget import BitgetPublic
from macrovex.news import fetch_events

st.set_page_config(page_title='MacroVex 2.1 Pro',page_icon='🧠',layout='wide')
st.title('🧠 MacroVex 2.1 Pro')
st.caption('Event-driven agent for 24/7 tokenized US-stock markets • paper-first • 20-gate risk engine')

journal=Journal(); broker=PaperBroker(); engine=MacroVex(journal); bg=BitgetPublic()
with st.sidebar:
    st.subheader('Agent controls')
    symbols=st.multiselect('Watchlist',['rNVDAUSDT','rAAPLUSDT','rTSLAUSDT','rAMDUSDT','rMSFTUSDT','rAMZNUSDT','rGOOGLUSDT','rMETAUSDT'],default=['rNVDAUSDT','rAAPLUSDT','rTSLAUSDT','rAMDUSDT'])
    if st.button('🔎 Scan now',type='primary'):
        with st.spinner('Scanning news + Bitget market data + risk gates...'):
            st.session_state['decisions']=engine.scan(symbols)
    st.markdown('**Execution:** PAPER ONLY')
    st.markdown('**Live orders:** disabled in this build')

try:
    syms=bg.reality_symbols(); st.sidebar.success(f'{len(syms)} rToken symbols discovered')
except Exception as e:
    syms=[]; st.sidebar.warning('Bitget public feed unavailable; retry later.')

decs=st.session_state.get('decisions',[])
cols=st.columns(4)
cols[0].metric('Decisions',len(decs))
cols[1].metric('Actionable',sum(d.action!='NO_TRADE' for d in decs))
cols[2].metric('Open paper positions',len(broker.positions()))
tr=journal.trades(); cols[3].metric('Closed paper trades',len(tr))

st.subheader('Latest agent decisions')
if decs:
    rows=[{'Symbol':d.symbol,'Action':d.action,'Score':d.score,'Confidence':d.confidence,'Entry':round(d.entry,4),'Stop':round(d.stop,4),'TP':round(d.take_profit,4),'Size USDT':round(d.size_usdt,2),'Regime':d.regime,'Hedge':d.hedge} for d in decs]
    st.dataframe(pd.DataFrame(rows),use_container_width=True,hide_index=True)
    d=decs[0]
    st.markdown('### 20-gate audit')
    gate_df=pd.DataFrame([{'Gate':k,'PASS':v} for k,v in d.gates.items()])
    st.dataframe(gate_df,use_container_width=True,hide_index=True)
    st.info(' | '.join(d.reasons))
else:
    st.info('Press Scan now. The agent will use public Bitget market data and event feeds; no API key is required for this demo.')

st.subheader('Live rToken watch')
watch=[]
for s in symbols:
    try:
        t=bg.ticker(s); watch.append({'Symbol':s,'Last':float(t.get('lastPr') or t.get('last')),'24h %':float(t.get('change24h') or 0)*100,'24h Volume':float(t.get('baseVolume') or 0)})
    except Exception: pass
if watch: st.dataframe(pd.DataFrame(watch),use_container_width=True,hide_index=True)

st.subheader('Event feed')
events=fetch_events()
if events:
    st.dataframe(pd.DataFrame([{'Time':pd.to_datetime(e.published,unit='s',utc=True),'Severity':e.severity,'Topics':', '.join(e.topics),'Assets':', '.join(e.assets),'Headline':e.title,'Source':e.source} for e in events[:15]]),use_container_width=True,hide_index=True)
else: st.warning('No classified event found in the configured feeds right now.')

st.subheader('Paper trade journal')
if not tr.empty:
    tr['Cum PnL']=tr.pnl.cumsum(); st.dataframe(tr,use_container_width=True,hide_index=True)
    st.line_chart(tr.set_index('closed')['Cum PnL'])
else: st.caption('No closed paper trades yet.')

st.divider()
st.caption('MacroVex is a hackathon research/demo system. It does not promise profitability and does not place live orders.')
