from dataclasses import dataclass
import os
from dotenv import load_dotenv
load_dotenv()

@dataclass(frozen=True)
class Settings:
    bitget_base: str = os.getenv('BITGET_BASE_URL', 'https://api.bitget.com')
    llm_key: str = os.getenv('LLM_API_KEY', '')
    llm_base: str = os.getenv('LLM_BASE_URL', 'https://hackathon.bitgetops.com/v1')
    llm_model: str = os.getenv('LLM_MODEL', 'qwen3.8-max')
    starting_equity: float = float(os.getenv('STARTING_EQUITY', '10000'))
    max_risk_trade: float = float(os.getenv('MAX_RISK_PER_TRADE', '0.005'))
    max_daily_dd: float = float(os.getenv('MAX_DAILY_DRAWDOWN', '0.02'))
    poll_seconds: int = int(os.getenv('POLL_SECONDS', '60'))

SETTINGS = Settings()
