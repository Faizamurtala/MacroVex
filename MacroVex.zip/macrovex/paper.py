import sqlite3, os
from datetime import datetime, timezone
from .config import SETTINGS

class PaperBroker:
    def __init__(self,path='data/macrovex.db'):
        os.makedirs(os.path.dirname(path),exist_ok=True); self.db=sqlite3.connect(path,check_same_thread=False)
        self.db.execute('CREATE TABLE IF NOT EXISTS positions (symbol TEXT PRIMARY KEY, side TEXT, entry REAL, stop REAL, tp REAL, size_usdt REAL, opened TEXT)'); self.db.commit()
    def open(self,d):
        if d.action=='NO_TRADE': return False
        cur=self.db.execute('SELECT 1 FROM positions WHERE symbol=?',(d.symbol,))
        if cur.fetchone(): return False
        self.db.execute('INSERT INTO positions VALUES(?,?,?,?,?,?,?)',(d.symbol,d.action,d.entry,d.stop,d.take_profit,d.size_usdt,d.ts)); self.db.commit(); return True
    def positions(self):
        return self.db.execute('SELECT symbol,side,entry,stop,tp,size_usdt,opened FROM positions').fetchall()
    def close_if_hit(self, prices):
        closed=[]
        for symbol,side,entry,stop,tp,size,opened in self.positions():
            px=prices.get(symbol)
            if px is None: continue
            hit = (side=='LONG' and (px<=stop or px>=tp)) or (side=='SHORT' and (px>=stop or px<=tp))
            if hit:
                pnl=(px-entry)/entry*size*(1 if side=='LONG' else -1)
                self.db.execute('DELETE FROM positions WHERE symbol=?',(symbol,));
                self.db.execute('INSERT INTO trades(opened,closed,symbol,side,entry,exit,size_usdt,pnl,reason) VALUES(?,?,?,?,?,?,?,?,?)',(opened,datetime.now(timezone.utc).isoformat(),symbol,side,entry,px,size,pnl,'TP/SL hit'))
                self.db.commit(); closed.append((symbol,pnl))
        return closed
