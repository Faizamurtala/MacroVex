from .config import SETTINGS

SYSTEM='''You are MacroVex adversarial trading judge. You do not invent data. Given an event and deterministic market evidence, return JSON only: {"bias":"LONG|SHORT|NO_TRADE","veto":true|false,"reason":"max 35 words","hedge":"NONE|BTC|ETH|GOLD|OIL"}. Veto means reject the proposed trade because the thesis is internally inconsistent, stale, overextended, or missing confirmation.'''

def judge(event, evidence):
    if not SETTINGS.llm_key: return {'bias':'NO_TRADE','veto':False,'reason':'LLM disabled; deterministic risk engine used.','hedge':'NONE'}
    try:
        from openai import OpenAI
        c=OpenAI(api_key=SETTINGS.llm_key,base_url=SETTINGS.llm_base)
        r=c.chat.completions.create(model=SETTINGS.llm_model,temperature=0,max_tokens=160,messages=[{'role':'system','content':SYSTEM},{'role':'user','content':f'EVENT: {event}\nEVIDENCE: {evidence}'}])
        import json
        return json.loads(r.choices[0].message.content)
    except Exception as e:
        return {'bias':'NO_TRADE','veto':False,'reason':f'LLM unavailable: {type(e).__name__}','hedge':'NONE'}
