import time, re
import feedparser
from dataclasses import dataclass, asdict
from email.utils import parsedate_to_datetime

FEEDS = [
    'https://feeds.finance.yahoo.com/rss/2.0/headline?s=NVDA,AAPL,TSLA,MSFT,AMD,AMZN,GOOGL&region=US&lang=en-US',
    'https://www.sec.gov/news/pressreleases.rss',
    'https://www.federalreserve.gov/feeds/press_all.xml',
]
KEYWORDS = {
    'inflation':['cpi','inflation','ppi','prices'], 'rates':['fed','fomc','rate cut','rate hike','interest rate'],
    'jobs':['jobs','payroll','unemployment','jobless'], 'geopolitics':['war','tariff','sanction','iran','israel','ukraine','china','export control'],
    'earnings':['earnings','revenue','eps','guidance','forecast'], 'regulation':['sec','regulation','antitrust','ban','lawsuit'],
    'ai':['artificial intelligence','ai','chip','gpu','data center'], 'oil':['oil','opec','crude'],
}
ASSETS=['rNVDAUSDT','rAAPLUSDT','rTSLAUSDT','rAMDUSDT','rMSFTUSDT','rAMZNUSDT','rGOOGLUSDT','rMETAUSDT','rPLTRUSDT','rMSTRUSDT']
TICKER_MAP={s.lower().replace('r','',1).replace('usdt',''):s for s in ASSETS}

@dataclass
class Event:
    title:str; link:str; published:int; topics:list; assets:list; severity:float; source:str
    def dict(self): return asdict(self)

def _ts(entry):
    for key in ('published','updated'):
        if getattr(entry,key,None):
            try: return int(parsedate_to_datetime(getattr(entry,key)).timestamp())
            except Exception: pass
    return int(time.time())

def classify(title):
    t=title.lower(); topics=[k for k, words in KEYWORDS.items() if any(w in t for w in words)]
    assets=[]
    for ticker,sym in TICKER_MAP.items():
        if re.search(r'\b'+re.escape(ticker)+r'\b', t): assets.append(sym)
    severity=min(1.0, 0.25*len(topics)+0.25*len(assets))
    if any(k in t for k in ['breaking','unexpected','emergency','surprise','imposes','cuts','raises']): severity=min(1.0,severity+0.3)
    return topics, assets, severity

def fetch_events(max_per_feed=20):
    out=[]
    for url in FEEDS:
        try:
            feed=feedparser.parse(url)
            for e in feed.entries[:max_per_feed]:
                title=getattr(e,'title','').strip()
                if not title: continue
                topics,assets,severity=classify(title)
                if topics or assets:
                    out.append(Event(title, getattr(e,'link',''), _ts(e), topics, assets, severity, url.split('/')[2]))
        except Exception:
            continue
    return sorted(out,key=lambda x:x.published,reverse=True)
