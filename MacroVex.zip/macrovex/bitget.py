import requests
import pandas as pd
from .config import SETTINGS

class BitgetPublic:
    def __init__(self, base=None):
        self.base = base or SETTINGS.bitget_base
        self.s = requests.Session()
        self.s.headers.update({'User-Agent':'MacroVex/2.1'})

    def get(self, path, params=None):
        r = self.s.get(self.base + path, params=params, timeout=15)
        r.raise_for_status()
        data = r.json()
        if data.get('code') not in (None, '00000', 0):
            raise RuntimeError(f"Bitget API: {data}")
        return data.get('data', data)

    def reality_symbols(self):
        rows = self.get('/api/v3/market/instruments', {'category':'SPOT'})
        return [x['symbol'] for x in rows if str(x.get('isReality','')).lower() == 'yes']

    def ticker(self, symbol):
        rows = self.get('/api/v3/market/tickers', {'category':'SPOT','symbol':symbol})
        return rows[0] if isinstance(rows, list) and rows else rows

    def candles(self, symbol, interval='5m', limit=200):
        rows = self.get('/api/v3/market/candles', {'category':'SPOT','symbol':symbol,'interval':interval,'limit':limit})
        # Bitget candles are commonly [ts, open, high, low, close, volume, turnover]
        cols=['ts','open','high','low','close','volume','turnover']
        df=pd.DataFrame(rows, columns=cols[:len(rows[0])] if rows else cols)
        if df.empty: return df
        for c in cols[1:]:
            if c in df: df[c]=pd.to_numeric(df[c], errors='coerce')
        df['ts']=pd.to_numeric(df['ts'], errors='coerce')
        df=df.sort_values('ts').reset_index(drop=True)
        return df
