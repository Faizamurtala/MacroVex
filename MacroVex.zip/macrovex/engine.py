from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import math, json, sqlite3, os
import numpy as np
import pandas as pd
from .bitget import BitgetPublic
from .news import Event, fetch_events
from .config import SETTINGS

GATES = [
 'fresh_event','asset_match','price_reaction','volume_confirmation','cross_asset_confirmation',
 'trend_alignment','structure_break','liquidity_sweep','fair_value_gap','regime_fit',
 'volatility_ok','spread_ok','reward_risk','drawdown_budget','portfolio_exposure',
 'correlation_budget','leverage_cap','session_context','duplicate_event','adversarial_veto'
]

@dataclass
class Decision:
    ts:str; symbol:str; action:str; score:float; confidence:float; entry:float; stop:float; take_profit:float
    size_usdt:float; event:str; reasons:list; gates:dict; regime:str; hedge:str='NONE'
    llm_reason:str='Deterministic fallback; LLM not configured.'
    def dict(self): return asdict(self)

class Journal:
    def __init__(self,path='data/macrovex.db'):
        os.makedirs(os.path.dirname(path),exist_ok=True)
        self.db=sqlite3.connect(path,check_same_thread=False)
        self.db.execute('CREATE TABLE IF NOT EXISTS decisions (id INTEGER PRIMARY KEY, ts TEXT, symbol TEXT, action TEXT, score REAL, confidence REAL, entry REAL, stop REAL, take_profit REAL, size_usdt REAL, event TEXT, reasons TEXT, gates TEXT, regime TEXT, hedge TEXT, llm_reason TEXT)')
        self.db.execute('CREATE TABLE IF NOT EXISTS trades (id INTEGER PRIMARY KEY, opened TEXT, closed TEXT, symbol TEXT, side TEXT, entry REAL, exit REAL, size_usdt REAL, pnl REAL, reason TEXT)')
        self.db.commit()
    def log_decision(self,d):
        self.db.execute('INSERT INTO decisions(ts,symbol,action,score,confidence,entry,stop,take_profit,size_usdt,event,reasons,gates,regime,hedge,llm_reason) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
          (d.ts,d.symbol,d.action,d.score,d.confidence,d.entry,d.stop,d.take_profit,d.size_usdt,d.event,json.dumps(d.reasons),json.dumps(d.gates),d.regime,d.hedge,d.llm_reason)); self.db.commit()
    def decisions(self,limit=200):
        return pd.read_sql_query('SELECT * FROM decisions ORDER BY id DESC LIMIT ?',self.db,params=(limit,))
    def trades(self): return pd.read_sql_query('SELECT * FROM trades ORDER BY id DESC',self.db)

class RiskEngine:
    def __init__(self, journal): self.journal=journal
    def evaluate(self, *, event, symbol, df, cross, equity, daily_pnl=0, existing_exposure=0, llm_veto=False):
        close=df.close.astype(float); vol=df.volume.astype(float) if 'volume' in df else pd.Series(dtype=float)
        px=float(close.iloc[-1]); ret=close.pct_change().dropna(); rv=float(ret.tail(48).std()*math.sqrt(288)) if len(ret)>10 else 0.0
        ema20=float(close.ewm(span=20).mean().iloc[-1]); ema50=float(close.ewm(span=50).mean().iloc[-1])
        trend='BULL' if px>ema20>ema50 else 'BEAR' if px<ema20<ema50 else 'MIXED'
        atr=float((df.high-df.low).rolling(14).mean().iloc[-1]) if len(df)>14 else px*0.01
        if not np.isfinite(atr) or atr<=0: atr=px*0.01
        z=float((ret.iloc[-1]-ret.tail(48).mean())/(ret.tail(48).std()+1e-9)) if len(ret)>50 else 0
        vol_ratio=float(vol.iloc[-1]/(vol.tail(48).median()+1e-9)) if len(vol)>48 else 1.0
        recent_high=float(close.tail(30).max()); recent_low=float(close.tail(30).min())
        structure_break = px>recent_high*0.998 or px<recent_low*1.002
        sweep = (float(df.low.iloc[-1])<float(df.low.tail(20).min()) and px>float(df.low.iloc[-1])) or (float(df.high.iloc[-1])>float(df.high.tail(20).max()) and px<float(df.high.iloc[-1]))
        regime='HIGH_VOL' if rv>0.75 else 'TREND' if abs(ema20/ema50-1)>0.008 else 'RANGE'
        event_fresh=(pd.Timestamp.now(tz='UTC').timestamp()-event.published)<4*3600
        asset_match=symbol in event.assets or not event.assets
        event_dir=-1 if any(k in event.topics for k in ['inflation','rates','geopolitics','regulation']) else 1
        tech_dir=1 if trend=='BULL' else -1 if trend=='BEAR' else 0
        cross_score=float(np.mean(list(cross.values()))) if cross else 0.0
        raw=0.0
        raw += event.severity*25*event_dir
        raw += 20*tech_dir
        raw += 15*np.sign(z)
        raw += 15*np.sign(cross_score)
        raw += 10 if structure_break else 0
        raw += 5 if sweep else 0
        raw=max(-100,min(100,raw))
        confidence=min(0.99,0.50+abs(raw)/220 + event.severity*0.15)
        action='NO_TRADE'
        if raw>=45: action='LONG'
        elif raw<=-45: action='SHORT'
        # risk geometry
        stop=px-(1 if action=='LONG' else -1)*max(1.5*atr,px*0.006)
        tp=px+(1 if action=='LONG' else -1)*max(3.0*atr,px*0.012)
        rr=abs(tp-px)/(abs(px-stop)+1e-9)
        gates={
          'fresh_event':event_fresh,'asset_match':asset_match,'price_reaction':abs(z)>=0.5,
          'volume_confirmation':vol_ratio>=0.8,'cross_asset_confirmation':abs(cross_score)>=0.15,
          'trend_alignment':(action=='LONG' and trend=='BULL') or (action=='SHORT' and trend=='BEAR'),
          'structure_break':structure_break,'liquidity_sweep':sweep,'fair_value_gap':abs(z)>=1.0,
          'regime_fit':not(regime=='HIGH_VOL' and event.severity<0.6),'volatility_ok':rv<1.25,
          'spread_ok':True,'reward_risk':rr>=1.8,'drawdown_budget':daily_pnl>-equity*SETTINGS.max_daily_dd,
          'portfolio_exposure':existing_exposure<equity*0.20,'correlation_budget':True,'leverage_cap':True,
          'session_context':True,'duplicate_event':True,'adversarial_veto':not llm_veto
        }
        # Critical gates required. Do not force a trade.
        critical=['fresh_event','asset_match','volatility_ok','reward_risk','drawdown_budget','portfolio_exposure','adversarial_veto']
        if action!='NO_TRADE' and not all(gates[k] for k in critical): action='NO_TRADE'
        risk_usdt=equity*SETTINGS.max_risk_trade
        unit_risk=abs(px-stop)
        size=(risk_usdt/unit_risk*px) if unit_risk>0 and action!='NO_TRADE' else 0
        size=min(size,equity*0.10)
        reasons=[f'event={event.title}',f'regime={regime}',f'trend={trend}',f'z={z:.2f}',f'volume_ratio={vol_ratio:.2f}',f'cross_asset={cross_score:.2f}',f'R:R={rr:.2f}']
        return Decision(datetime.now(timezone.utc).isoformat(),symbol,action,round(raw,2),round(confidence,3),px,stop,tp,size,event.title,reasons,gates,regime, hedge='NONE')

class MacroVex:
    def __init__(self,journal=None):
        self.bg=BitgetPublic(); self.journal=journal or Journal()
    def cross_asset(self):
        scores={}
        for s in ['BTCUSDT','ETHUSDT']:
            try:
                d=self.bg.candles(s,'5m',80); r=d.close.pct_change().tail(12).mean(); scores[s]=float(np.sign(r)*min(1,abs(r)*100))
            except Exception: scores[s]=0.0
        return scores
    def scan(self, symbols=None):
        events=fetch_events()
        if not events: return []
        symbols=symbols or ['rNVDAUSDT','rAAPLUSDT','rTSLAUSDT','rAMDUSDT','rMSFTUSDT']
        cross=self.cross_asset(); out=[]
        for ev in events[:8]:
            targets=ev.assets or symbols[:2]
            for sym in targets:
                if sym not in symbols: continue
                try:
                    df=self.bg.candles(sym,'5m',200)
                    if df.empty: continue
                    d=RiskEngine(self.journal).evaluate(event=ev,symbol=sym,df=df,cross=cross,equity=SETTINGS.starting_equity)
                    self.journal.log_decision(d); out.append(d)
                except Exception as e:
                    continue
        return out
