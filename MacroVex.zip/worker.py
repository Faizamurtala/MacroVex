import time, logging
from macrovex.engine import MacroVex
from macrovex.paper import PaperBroker
from macrovex.bitget import BitgetPublic
from macrovex.config import SETTINGS

logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
engine=MacroVex(); broker=PaperBroker(); bg=BitgetPublic()
SYMS=['rNVDAUSDT','rAAPLUSDT','rTSLAUSDT','rAMDUSDT','rMSFTUSDT']
while True:
    try:
        decisions=engine.scan(SYMS)
        prices={}
        for s in SYMS:
            try: prices[s]=float(bg.ticker(s).get('lastPr') or bg.ticker(s).get('last'))
            except Exception: pass
        for d in decisions:
            if d.action!='NO_TRADE': broker.open(d)
        closed=broker.close_if_hit(prices)
        logging.info('scan=%s actionable=%s open=%s closed=%s',len(decisions),sum(d.action!='NO_TRADE' for d in decisions),len(broker.positions()),closed)
    except Exception:
        logging.exception('agent loop error')
    time.sleep(SETTINGS.poll_seconds)
