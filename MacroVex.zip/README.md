# MacroVex 2.1 Pro

**Bitget AI Hackathon S2 — Agentic Trading / Event-Driven Agent**

MacroVex is a paper-first event-driven trading agent for Bitget Reality/rToken markets. Its differentiator is a **causal event → cross-asset → structure → regime → adversarial risk** pipeline instead of a single BUY/SELL prompt.

## What is actually implemented

- Public Bitget UTA v3 market discovery and ticker/candle ingestion.
- Reality/rToken discovery using the `isReality` instrument flag.
- Event ingestion from public RSS feeds.
- Cross-asset confirmation using BTC/ETH context.
- Trend, volatility, structure break, liquidity sweep and abnormal-return features.
- 20 named risk gates.
- Position sizing from a fixed portfolio-risk budget.
- Paper broker with SQLite journal and TP/SL exits.
- Optional Qwen/OpenAI-compatible adversarial judge.
- Streamlit dashboard.
- Long-running worker for continuous paper monitoring.
- Docker + Render configuration.

## Safety

The included build is **paper only**. It deliberately does not contain live order placement. Bitget's official Agent Hub supports read-only and paper-trading modes; when you later integrate the official SDK/MCP, use a Demo API key first.

## Local setup

```bash
git clone <your-repo>
cd macrovex-2-1-pro
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
cp .env.example .env
streamlit run app.py
```

Open `http://localhost:8501`.

### Optional LLM

Put these in `.env`:

```env
LLM_API_KEY=your_key
LLM_BASE_URL=https://hackathon.bitgetops.com/v1
LLM_MODEL=qwen3.8-max
```

Without an LLM, MacroVex still runs using deterministic logic and labels the LLM gate as fallback.

## Continuous paper agent

```bash
python worker.py
```

It scans periodically, records decisions, opens paper positions, and closes them when TP/SL is hit.

## Deploy the dashboard

### Streamlit Community Cloud

1. Push this repo to GitHub.
2. Create a new Streamlit app.
3. Main file: `app.py`.
4. Python requirements: `requirements.txt`.
5. Add `LLM_API_KEY`, `LLM_BASE_URL`, and `LLM_MODEL` in Streamlit Secrets if using Qwen.
6. Deploy.

### Render

Use the included `render.yaml`. The web service hosts the dashboard and the worker service keeps the paper agent running.

### Docker

```bash
docker build -t macrovex .
docker run -p 8501:8501 --env-file .env macrovex
```

## Bitget Agent Hub integration path

The official Agent Hub currently exposes the Bitget AI ecosystem around the UTA v3 API. The official repository documents `bitget-agent-sdk`, `bitget-agent-cli`, `bitget-agent-mcp`, and `bitget-signal`. For the hackathon demo, keep MacroVex paper-only and show the architecture boundary:

`MacroVex perception/risk → Agent Hub market/trading capability → paper execution`

Do not put exchange credentials in GitHub. Use Demo API credentials and Bitget's paper-trading mode for any authenticated testing.

## Submission evidence to capture

- Public dashboard URL.
- GitHub repository URL.
- Screenshot/video of one event flowing through the 20 gates.
- Paper journal showing decisions and exits.
- A short architecture diagram.
- A table of observed metrics from the actual run. Never fabricate metrics.

## Suggested project thesis

> MacroVex is an event-driven AI trading agent that does not treat a headline as a trade. It maps the event to assets, checks cross-asset confirmation and market structure, detects the current regime, sizes risk, challenges the thesis, and only then permits a paper position. The key output is not BUY or SELL; it is a fully audited decision with explicit reasons for both trading and refusing to trade.
