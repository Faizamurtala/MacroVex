import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from macrovex.engine import GATES

def test_twenty_gates():
    assert len(GATES)==20
